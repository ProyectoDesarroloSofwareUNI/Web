using PreMatricula.Entity.DTO;
namespace PreMatricula.Entity.Response
{
  public class ResponseBase
  {
    public ResponseBaseDTO RespuestaServicio { get; set; }
  }
}
