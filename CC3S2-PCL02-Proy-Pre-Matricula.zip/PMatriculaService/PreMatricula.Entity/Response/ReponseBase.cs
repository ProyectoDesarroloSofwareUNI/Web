using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PreMatricula.Entity.DTO;

namespace PreMatricula.Entity.Response
{
  public class ResponseBase
  {
    public ResponseBaseDTO RespuestaServicio { get; set; }
  }
}
